---
name: {{name}}
description: Use when <the situations that should trigger this skill — be concrete and a little pushy>. <What it produces.>
---

# {{name}}

> **TeamFlow configuration.** Read `.teamflow/config.yml` if it exists and respect it.

## When to use

- <situation 1>
- <situation 2>

## Process

1. <step>
2. <step>
3. <step>

## Output

<What the user gets: file, report, change.>

## Next step (suggested, never forced)

- <condition> → <tf-skill>
