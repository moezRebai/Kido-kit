## TeamFlow

For every message about work in this repository, load the `teamflow` skill first and follow its routing table before doing anything else. Exceptions: the user explicitly named a `tf-*` skill (load it directly), or the message is purely conversational. Configuration: `.teamflow/config.yml`.
