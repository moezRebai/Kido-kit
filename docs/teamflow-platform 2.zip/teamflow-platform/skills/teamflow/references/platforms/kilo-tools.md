# Kilo Code Tool Notes

The skills were written with Claude Code vocabulary (`Agent`/`Task` for a subagent dispatch, `TodoWrite`, `Skill`). Read them with the Kilo Code equivalents below.

- **Skills** are discovered from `.kilo/skills/` (project) and `~/.config/kilo/skills/` (global). Check with `kilo debug skill`.
- **Agents** are Markdown files with YAML front matter (`description`, `mode: primary | subagent | all`, `permission`). The TeamFlow router is a `primary` agent.
- **Subagent dispatch**: use Kilo's task/subagent tool to run an agent with `mode: subagent`. If no subagent tool is available in the session, use tf-implement (inline) instead of tf-implement-subagents. Never fabricate a dispatch.
- **Worktrees**: if Kilo offers no native worktree tool, use the `git worktree` fallback in tf-worktree.
- **Scripts**: some skills call bash scripts (`scripts/…`). On Windows, run them with Git Bash or WSL.

> Written from Kilo's public docs; check against the Kilo version in use (tool names change between releases).
