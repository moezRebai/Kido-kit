---
name: teamflow
description: TeamFlow router. Use FIRST for every message about work in this repository — new feature, bug, plan, implementation, review, merge, documentation, tests, or any question about which TeamFlow skill to use. Picks the right tf-* skill and hands off to it.
---

# TeamFlow — Router

You are running the routing step. Its only output is a decision: which skill handles this message. Do not start the work before the target skill is loaded.

## 1. Read the configuration (silently)

Read `.teamflow/config.yml` if it exists. You only need:

- `implement.mode` — `inline` (default) or `subagents`
- `review.skill` — default `tf-review`

Missing file or field → defaults.

## 2. Decision table

Evaluate top to bottom. First match wins.

<!-- routes:start -->
<!-- routes:end -->

Special targets: **bypass** = load the skill the user named; **help** = list the skills above in a few lines; **answer** = reply normally; **ask** = one question with 2–3 options.

## 3. Resolve the target

- Route `implement` → `tf-implement-subagents` if `implement.mode` is `subagents`, otherwise `tf-implement`.
- Route `review` → the skill named in `review.skill` if set, otherwise `tf-review`.
- Compound request ("document then plan the rewrite") → route to the first needed skill and say which one comes next.

## 4. Hand off

Announce the choice in one short line (for example `→ tf-specify`), load the target skill, and follow it from there. The skills chain by themselves: when a skill proposes the next one and the user agrees, load that skill directly.

## 5. Rules

- At most **one** clarifying question before routing.
- The routing step itself never writes files, runs git, or calls external systems.
- Don't recite this table unless the user asks for help.
- Routes for project-specific skills come from `.teamflow/routes/*.yml` and are merged into this table by `teamflow-bootstrap sync`. Never edit the table by hand.
