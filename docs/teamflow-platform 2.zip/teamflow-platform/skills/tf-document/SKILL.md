---
name: tf-document
description: Use when the user wants documentation of an existing project, service or module — functional docs, technical docs, architecture overview, onboarding notes — or wants to understand a codebase before changing it. Produces docs grounded in the code, with file references, never invented.
---

# Documenting Existing Code

> **TeamFlow configuration.** Read `.teamflow/config.yml` if it exists. Output folder: `paths.docs` (default `docs/teamflow/docs`). Commits follow `git.commitArtifacts` (`ask` by default); never commit to the default branch without explicit approval.

## Rule

Every statement in the documentation must come from something you read in the repository. If you cannot verify it, write it under **Open questions**, not as fact.

## Process

1. **Scope** — confirm what to document (whole repo, one service, one module) and the audience (new developer, ops, business). One question if unclear.
2. **Detect the stack** — build files, package manifests, solution files, Dockerfiles, CI config. Note languages, frameworks, versions.
3. **Find the entry points** — main programs, hosts, controllers, message handlers, scheduled jobs, CLI commands.
4. **Map the components** — modules, their responsibilities, the dependencies between them, external systems (databases, queues, APIs).
5. **Follow two or three key flows** end to end, from entry point to storage or external call.
6. **Read configuration and operations** — settings, environment variables (names only, never values), deployment, logging.
7. **Write** the document (template below). Use Mermaid for diagrams. Reference files as `path/to/file.ext`.
8. **Self-check** — every section backed by a file reference; no secrets; unknowns listed.
9. **Hand over** — give the path and ask the user to review.

## Template

```markdown
# <Scope> — Documentation

## Purpose
What it does and for whom.

## Functional overview
Main features and business flows.

## Architecture
Components, responsibilities, dependencies (Mermaid diagram).

## Key flows
Step-by-step for the 2–3 most important flows, with file references.

## Data
Main entities, storage, external data sources.

## Configuration and operations
Settings (names only), deployment, logging, monitoring.

## Open questions
What could not be verified from the code.
```

## Next step (suggested)

- A change is planned on this code → tf-specify.
- Something looks broken while reading → tf-debug.
