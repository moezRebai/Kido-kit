# Third-party notice

Most `tf-*` skills in `skills/` are derived from **Superpowers** by Jesse Vincent and contributors
(https://github.com/obra/superpowers), distributed under the **MIT License**.

Derived skills: tf-specify, tf-planify, tf-implement, tf-implement-subagents, tf-tdd, tf-review,
tf-review-feedback, tf-verify, tf-finish, tf-worktree, tf-debug, tf-parallel-agents, tf-writing-skills.

Changes made for TeamFlow: renamed skills and cross-references (`superpowers:*` → `tf-*`); paths
`docs/superpowers/` → configurable `docs/teamflow/`, `.superpowers/` → `.teamflow/`; added TeamFlow
configuration blocks (TDD and review settings, commit rules); removed the brainstorming browser
companion; removed the per-harness tool notes (TeamFlow targets Kilo Code only); removed bootstrap and diagnostic skills replaced by the TeamFlow router.

**Before any distribution**, add the upstream `LICENSE` file verbatim as `LICENSE-superpowers`:
the MIT License requires its copyright notice and permission notice to ship with copies.
It could not be retrieved automatically while this package was prepared.

`teamflow`, `tf-document`, the CLI, templates and hooks are TeamFlow's own work.
