import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import YAML from 'yaml';

export const PKG_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const SPECIAL_TARGETS = new Set(['bypass', 'help', 'answer', 'ask']);
const ROUTER = 'teamflow';

// ---------- config ----------
export const DEFAULT_CONFIG = {
  paths: { specs: 'docs/teamflow/specs', plans: 'docs/teamflow/plans', docs: 'docs/teamflow/docs' },
  implement: { mode: 'inline', tdd: 'required' },
  review: { perTask: true, final: true, skill: 'tf-review', checklist: '' },
  git: { commitArtifacts: 'ask' },
  adapters: { kilo: { agentDir: '' } },
};

function merge(base, over) {
  if (Array.isArray(base) || typeof base !== 'object' || base === null) return over ?? base;
  const out = { ...base };
  for (const [k, v] of Object.entries(over || {})) out[k] = k in base ? merge(base[k], v) : v;
  return out;
}

export function loadConfig(projectDir) {
  const p = path.join(projectDir, '.teamflow', 'config.yml');
  if (!fs.existsSync(p)) return { config: DEFAULT_CONFIG, exists: false };
  return { config: merge(DEFAULT_CONFIG, YAML.parse(fs.readFileSync(p, 'utf8')) || {}), exists: true };
}

export function validateConfig(c) {
  const errors = [];
  const oneOf = (v, allowed, name) => { if (!allowed.includes(v)) errors.push(`${name} must be one of ${allowed.join(', ')} (got "${v}")`); };
  oneOf(c.implement.mode, ['inline', 'subagents'], 'implement.mode');
  oneOf(c.implement.tdd, ['required', 'recommended', 'off'], 'implement.tdd');
  oneOf(c.git.commitArtifacts, ['ask', 'auto', 'never'], 'git.commitArtifacts');
  for (const k of ['perTask', 'final']) if (typeof c.review[k] !== 'boolean') errors.push(`review.${k} must be true or false`);
  return errors;
}

// ---------- skills & routes ----------
export function listSkills(projectDir) {
  const skills = new Map(); // name -> source dir
  const add = (dir) => {
    if (!fs.existsSync(dir)) return;
    for (const name of fs.readdirSync(dir)) {
      const d = path.join(dir, name);
      if (fs.existsSync(path.join(d, 'SKILL.md'))) skills.set(name, d);
    }
  };
  add(path.join(PKG_ROOT, 'skills'));
  add(path.join(projectDir, '.teamflow', 'skills')); // project skills override package skills of the same name
  return skills;
}

export function loadRoutes(projectDir) {
  const base = YAML.parse(fs.readFileSync(path.join(PKG_ROOT, 'routing.yml'), 'utf8')).routes;
  const byId = new Map(base.map((r) => [r.id, { ...r, source: 'package' }]));
  const dir = path.join(projectDir, '.teamflow', 'routes');
  if (fs.existsSync(dir)) {
    for (const f of fs.readdirSync(dir).filter((f) => /\.ya?ml$/.test(f)).sort()) {
      const doc = YAML.parse(fs.readFileSync(path.join(dir, f), 'utf8')) || {};
      for (const r of doc.routes || []) byId.set(r.id, { ...r, source: `.teamflow/routes/${f}` });
    }
  }
  return [...byId.values()].sort((a, b) => a.order - b.order);
}

export function validateRoutes(routes, skills, config) {
  const errors = [];
  const ids = new Set();
  for (const r of routes) {
    const where = `route "${r.id}" (${r.source})`;
    if (!r.id || typeof r.order !== 'number' || !r.when || !r.target) errors.push(`${where}: needs id, order (number), when, target`);
    if (ids.has(r.id)) errors.push(`${where}: duplicate id`);
    ids.add(r.id);
    for (const t of [r.target, r.alt].filter(Boolean)) {
      if (!SPECIAL_TARGETS.has(t) && !skills.has(t)) errors.push(`${where}: target skill "${t}" is not installed`);
    }
  }
  if (config && !skills.has(config.review.skill)) errors.push(`review.skill "${config.review.skill}" is not installed`);
  if (!skills.has(ROUTER)) errors.push('router skill "teamflow" is missing');
  return errors;
}

const cell = (s) => String(s ?? '').replace(/\|/g, '\\|').replace(/\n/g, ' ');

export function renderRouteTable(routes) {
  const lines = ['| # | When | Route to | Examples |', '|---|---|---|---|'];
  routes.forEach((r, i) => {
    let target = SPECIAL_TARGETS.has(r.target) ? `**${r.target}**` : `\`${r.target}\``;
    if (r.alt) target += ` / \`${r.alt}\``;
    if (r.note) target += ` — ${r.note}`;
    const ex = (r.examples || []).map((e) => `"${e}"`).join(', ');
    lines.push(`| ${i + 1} | ${cell(r.when)} | ${cell(target)} | ${cell(ex)} |`);
  });
  return lines.join('\n');
}

export function replaceBlock(text, tag, content) {
  const re = new RegExp(`(<!-- ${tag}:start -->)[\\s\\S]*?(<!-- ${tag}:end -->)`);
  if (!re.test(text)) throw new Error(`markers <!-- ${tag}:start/end --> not found`);
  return text.replace(re, `$1\n${content}\n$2`);
}

// ---------- destinations (Kilo Code) ----------
export function destinations({ projectDir, global, config }) {
  const home = os.homedir();
  const agentOverride = config.adapters?.kilo?.agentDir;
  return global
    ? { skills: path.join(home, '.config', 'kilo', 'skills'), agentDir: agentOverride || path.join(home, '.config', 'kilo', 'agent'), agentsMd: null }
    : { skills: path.join(projectDir, '.kilo', 'skills'), agentDir: agentOverride ? path.resolve(projectDir, agentOverride) : path.join(projectDir, '.kilo', 'agent'), agentsMd: path.join(projectDir, 'AGENTS.md') };
}

// ---------- safe writer (never overwrites user-edited files) ----------
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

export class Writer {
  constructor(manifestPath, { force = false, log = console.log } = {}) {
    this.manifestPath = manifestPath;
    this.force = force;
    this.log = log;
    this.manifest = fs.existsSync(manifestPath) ? JSON.parse(fs.readFileSync(manifestPath, 'utf8')) : {};
    this.stats = { written: 0, unchanged: 0, skipped: 0 };
  }
  write(file, content) {
    const buf = Buffer.isBuffer(content) ? content : Buffer.from(content);
    const next = sha(buf);
    if (fs.existsSync(file)) {
      const current = sha(fs.readFileSync(file));
      if (current === next) { this.manifest[file] = next; this.stats.unchanged++; return; }
      const known = this.manifest[file];
      if (!this.force && known !== current) {
        this.log(`  ! kept your version of ${file} (modified outside TeamFlow; use --force to overwrite)`);
        this.stats.skipped++;
        return;
      }
    }
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, buf);
    this.manifest[file] = next;
    this.stats.written++;
  }
  copyDir(src, dest, transform) {
    for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
      const s = path.join(src, entry.name);
      const d = path.join(dest, entry.name);
      if (entry.isDirectory()) this.copyDir(s, d, transform);
      else this.write(d, transform ? transform(s, fs.readFileSync(s)) : fs.readFileSync(s));
    }
  }
  save() {
    fs.mkdirSync(path.dirname(this.manifestPath), { recursive: true });
    fs.writeFileSync(this.manifestPath, JSON.stringify(this.manifest, null, 2) + '\n');
  }
}

// ---------- merge helpers for shared files ----------
export function upsertMarkedBlock(file, block) {
  const start = '<!-- teamflow:start -->', end = '<!-- teamflow:end -->';
  const wrapped = `${start}\n${block.trim()}\n${end}`;
  let text = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
  const re = new RegExp(`${start}[\\s\\S]*?${end}`);
  text = re.test(text) ? text.replace(re, wrapped) : (text.trimEnd() + (text ? '\n\n' : '') + wrapped + '\n');
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, text);
}

// ---------- commands ----------
export function sync({ projectDir = process.cwd(), global = false, force = false, log = console.log } = {}) {
  const { config, exists } = loadConfig(projectDir);
  if (!exists && !global) {
    fs.mkdirSync(path.join(projectDir, '.teamflow', 'routes'), { recursive: true });
    fs.mkdirSync(path.join(projectDir, '.teamflow', 'skills'), { recursive: true });
    fs.copyFileSync(path.join(PKG_ROOT, 'templates', 'config.yml'), path.join(projectDir, '.teamflow', 'config.yml'));
    log('  + created .teamflow/config.yml');
  }
  const skills = listSkills(projectDir);
  const routes = loadRoutes(projectDir);
  const errors = [...validateConfig(config), ...validateRoutes(routes, skills, config)];
  if (errors.length) { errors.forEach((e) => log(`  x ${e}`)); throw new Error('configuration or routes invalid — nothing installed'); }

  const table = renderRouteTable(routes);
  const skillList = [...skills.keys()].filter((n) => n !== ROUTER).sort().map((n) => `   - \`${n}\``).join('\n');
  const renderSkillFile = (src, buf) =>
    src === path.join(skills.get(ROUTER), 'SKILL.md') ? Buffer.from(replaceBlock(buf.toString('utf8'), 'routes', table)) : buf;

  const manifest = global ? path.join(os.homedir(), '.teamflow', 'installed.json') : path.join(projectDir, '.teamflow', 'installed.json');
  const w = new Writer(manifest, { force, log });
  const d = destinations({ projectDir, global, config });

  log(`skills → ${d.skills}`);
  for (const [name, src] of skills) w.copyDir(src, path.join(d.skills, name), renderSkillFile);
  const agent = replaceBlock(fs.readFileSync(path.join(PKG_ROOT, 'templates', 'kilo-router-agent.md'), 'utf8'), 'skills', skillList);
  w.write(path.join(d.agentDir, 'teamflow-router.md'), agent);
  log(`router agent → ${path.join(d.agentDir, 'teamflow-router.md')}`);
  if (d.agentsMd) {
    upsertMarkedBlock(d.agentsMd, fs.readFileSync(path.join(PKG_ROOT, 'templates', 'agents-md-block.md'), 'utf8'));
    log(`routing rule → ${d.agentsMd}`);
  }
  w.save();
  log(`done: ${w.stats.written} written, ${w.stats.unchanged} unchanged, ${w.stats.skipped} kept (user-modified)`);
  return { stats: w.stats, routes, skills };
}

export function doctor({ projectDir = process.cwd(), log = console.log } = {}) {
  const { config, exists } = loadConfig(projectDir);
  const skills = listSkills(projectDir);
  const routes = loadRoutes(projectDir);
  const errors = [...validateConfig(config), ...validateRoutes(routes, skills, config)];
  const warnings = [];
  if (!exists) warnings.push('.teamflow/config.yml not found — defaults used (run sync to create it)');
  const d = destinations({ projectDir, global: false, config });
  if (!fs.existsSync(path.join(d.skills, ROUTER, 'SKILL.md'))) warnings.push('not installed in this project (run sync)');
  const routed = new Set(routes.flatMap((r) => [r.target, r.alt]).filter(Boolean));
  for (const name of skills.keys()) if (name !== ROUTER && !routed.has(name)) warnings.push(`skill "${name}" has no route (reachable only by name)`);
  log(`skills: ${skills.size}, routes: ${routes.length}`);
  warnings.forEach((m) => log(`  ! ${m}`));
  errors.forEach((m) => log(`  x ${m}`));
  log(errors.length ? 'doctor: FAILED' : 'doctor: OK');
  return { errors, warnings };
}

export function newSkill(name, { projectDir = process.cwd(), log = console.log } = {}) {
  if (!/^[a-z0-9][a-z0-9-]*$/.test(name)) throw new Error('skill name: lowercase letters, digits and dashes only');
  const dir = path.join(projectDir, '.teamflow', 'skills', name);
  const routeFile = path.join(projectDir, '.teamflow', 'routes', `${name}.yml`);
  if (fs.existsSync(dir)) throw new Error(`${dir} already exists`);
  const tpl = (f) => fs.readFileSync(path.join(PKG_ROOT, 'templates', f), 'utf8').replaceAll('{{name}}', name);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'SKILL.md'), tpl('new-skill.md'));
  fs.mkdirSync(path.dirname(routeFile), { recursive: true });
  if (!fs.existsSync(routeFile)) fs.writeFileSync(routeFile, tpl('new-route.yml'));
  log(`created ${path.relative(projectDir, dir)}/SKILL.md and ${path.relative(projectDir, routeFile)}`);
  log('edit both files, then run: npx teamflow-bootstrap sync');
}
