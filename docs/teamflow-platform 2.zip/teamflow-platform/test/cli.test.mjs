import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { sync, doctor, newSkill, listSkills, loadRoutes, validateRoutes, DEFAULT_CONFIG } from '../src/lib.mjs';

const quiet = () => {};
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'tf-'));
const read = (...p) => fs.readFileSync(path.join(...p), 'utf8');

test('package routes all point to installed skills', () => {
  const dir = tmp();
  assert.deepEqual(validateRoutes(loadRoutes(dir), listSkills(dir), DEFAULT_CONFIG), []);
});

test('sync installs skills, router table, router agent and AGENTS.md rule', () => {
  const dir = tmp();
  sync({ projectDir: dir, log: quiet });
  assert.ok(fs.existsSync(path.join(dir, '.teamflow', 'config.yml')));
  const router = read(dir, '.kilo', 'skills', 'teamflow', 'SKILL.md');
  assert.match(router, /`tf-specify`/);
  assert.match(router, /`tf-implement` \/ `tf-implement-subagents`/);
  assert.ok(fs.existsSync(path.join(dir, '.kilo', 'skills', 'tf-tdd', 'SKILL.md')));
  const agent = read(dir, '.kilo', 'agent', 'teamflow-router.md');
  assert.match(agent, /mode: primary/);
  assert.match(agent, /- `tf-debug`/);
  assert.match(read(dir, 'AGENTS.md'), /teamflow:start/);
  assert.ok(!fs.existsSync(path.join(dir, '.claude')));
});

test('sync is idempotent and keeps user-edited files', () => {
  const dir = tmp();
  fs.writeFileSync(path.join(dir, 'AGENTS.md'), '# My project\n\nExisting rules.\n');
  sync({ projectDir: dir, log: quiet });
  const again = sync({ projectDir: dir, log: quiet });
  assert.equal(again.stats.written, 0);
  const agentsMd = read(dir, 'AGENTS.md');
  assert.match(agentsMd, /Existing rules/);
  assert.equal(agentsMd.match(/teamflow:start/g).length, 1, 'block not duplicated');
  const f = path.join(dir, '.kilo', 'skills', 'tf-review', 'SKILL.md');
  fs.appendFileSync(f, '\nlocal tweak\n');
  assert.equal(sync({ projectDir: dir, log: quiet }).stats.skipped, 1);
  assert.match(read(f), /local tweak/);
  sync({ projectDir: dir, force: true, log: quiet });
  assert.doesNotMatch(read(f), /local tweak/);
});

test('new-skill + sync adds the skill and its route', () => {
  const dir = tmp();
  sync({ projectDir: dir, log: quiet });
  newSkill('release-notes', { projectDir: dir, log: quiet });
  sync({ projectDir: dir, log: quiet });
  assert.ok(fs.existsSync(path.join(dir, '.kilo', 'skills', 'release-notes', 'SKILL.md')));
  assert.match(read(dir, '.kilo', 'skills', 'teamflow', 'SKILL.md'), /`release-notes`/);
  assert.match(read(dir, '.kilo', 'agent', 'teamflow-router.md'), /- `release-notes`/);
  assert.equal(doctor({ projectDir: dir, log: quiet }).errors.length, 0);
});

test('a route to a missing skill blocks sync and fails doctor', () => {
  const dir = tmp();
  fs.mkdirSync(path.join(dir, '.teamflow', 'routes'), { recursive: true });
  fs.writeFileSync(path.join(dir, '.teamflow', 'routes', 'bad.yml'), 'routes:\n  - id: bad\n    order: 145\n    when: x\n    target: tf-ghost\n');
  assert.throws(() => sync({ projectDir: dir, log: quiet }), /invalid/);
  assert.ok(doctor({ projectDir: dir, log: quiet }).errors.some((e) => e.includes('tf-ghost')));
});

test('config validation rejects bad values and unknown review skill', () => {
  const dir = tmp();
  fs.mkdirSync(path.join(dir, '.teamflow'), { recursive: true });
  fs.writeFileSync(path.join(dir, '.teamflow', 'config.yml'), 'implement:\n  tdd: sometimes\nreview:\n  skill: pr-review\n');
  const { errors } = doctor({ projectDir: dir, log: quiet });
  assert.ok(errors.some((e) => e.includes('implement.tdd')));
  assert.ok(errors.some((e) => e.includes('pr-review')));
});

test('agentDir override is respected', () => {
  const dir = tmp();
  fs.mkdirSync(path.join(dir, '.teamflow'), { recursive: true });
  fs.writeFileSync(path.join(dir, '.teamflow', 'config.yml'), 'adapters:\n  kilo:\n    agentDir: .kilo/agents\n');
  sync({ projectDir: dir, log: quiet });
  assert.ok(fs.existsSync(path.join(dir, '.kilo', 'agents', 'teamflow-router.md')));
});
