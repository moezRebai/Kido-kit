# TeamFlow — Extended Routing Table

This file is loaded by the `teamflow` router skill on demand, when the main decision table in `SKILL.md §2` produces an ambiguous match or when an edge case needs clarification. Do not load it for clear-cut routing.

---

## 1. Signal detection guide

### Jira key (rule 2)
Pattern: `[A-Z][A-Z0-9]+-\d+` (e.g. `PROJ-123`, `DIE-7`, `MYTEAM-1042`).
Only triggers `tf-implement` when the intent is clearly **to work on** the ticket (implement, apply, code, fix). A Jira key used as a reference in a question ("what is PROJ-123 about?") does NOT trigger rule 2 — route to `tf-explain` or answer normally instead.

### Agent / analysis requests (rule 3)
Trigger words and phrases (case-insensitive):

| Trigger | Target |
|---|---|
| "sonarqube", "sonar scan", "code quality" | tf-agent-sonarqube |
| "checkmarx", "sast", "security scan" | tf-agent-checkmarx |
| "secrets", "leaked credentials", "secret scan" | tf-agent-secrets |
| "sanity check", "pre-PR check", "check everything" | tf-agent-sanity (runs the group) |
| "spec traceability", "does the code match the spec" | tf-agent-spec-traceability |

When multiple agents are named, route to `tf-agent-sanity` which orchestrates the group, and pass the individual agent names as hints.

### Resume signal (rule 5)
An in-progress topic matches when:
- The user names the topic id or slug, OR
- The user's message is thematically about the same subject as `activeTopic` (same feature name, same bug symptom), AND
- The topic is in a phase that is not `archived`.

If multiple active topics could match, list them and ask which one (this is the one permitted question under rule 13).

### Rebuild vs. new feature (rules 7 vs. 8)

| Signals → rebuild (rule 7) | Signals → new feature (rule 8) |
|---|---|
| "rewrite", "modernise", "rebuild", "migrate from", "replace with" | "add", "build", "implement", "new", "I want to be able to" |
| Subject is an **existing** application or service | Subject is a new capability or screen |
| Large scope implied ("the whole service", "from scratch") | Scoped increment implied |

When both signals are present, prefer rule 7 and confirm with the user.

### Team vs. solo (rules 8/9 vs. 11)

| Solo signals | Team signals |
|---|---|
| No Jira mention, no "push to Jira" | "create a ticket", "push to Jira", "for the team" |
| `userRole: solo` in profile | `userRole: team` in profile |
| `defaultMode: solo` in config | `defaultMode: team` in config |

User message always overrides profile and config.

---

## 2. Compound requests

When the message contains multiple intents (e.g. "document the service and then plan the rebuild"), route to the **first** required skill and tell the user that the next skill will be invoked after the current phase completes. Do not try to chain multiple skills in a single routing decision.

Example:
> "Can you document what we have and then help me plan the rewrite?"

→ Route to `tf-document` (mode `rebuild`). After it completes, the user will naturally continue and the router will pick up `tf-architecture` at that point.

---

## 3. Ambiguity examples and resolved decisions

| User message | Ambiguous rules | Clarifying question | Expected resolution |
|---|---|---|---|
| "I want to add a login screen" | 8 (feature) vs 11 (team) | "Is this for you alone or should I create a Jira ticket for the team?" | Rule 8 or 11 depending on answer |
| "Fix the broken auth" | 9 (bug) vs. 2 (Jira key absent) | None needed — no key present | Rule 9: tf-specify type=bug |
| "PROJ-42" with no other text | 2 (implement) vs. 10 (explain) | "Do you want to implement PROJ-42 or understand what it is?" | Route on answer |
| "Check the code before merging" | 3 (agents) vs. 11 (team) | None needed — "check" → sanity | Rule 3: tf-agent-sanity |
| "Let's continue" | 5 (resume) — but which topic? | "Which topic would you like to resume? [list active topics]" | Rule 5 after answer |
| "What does the payment service do?" | 10 (explain) vs. 12 (unrelated) | None needed — repo-specific question | Rule 10: tf-explain |

---

## 4. Explicit invocation bypass (rule 1)

The following patterns always bypass the router:

- Message starts with `/tf-` (slash command)
- Message contains `@tf-` (agent mention, if supported by the coding agent)
- The skill tool was called directly with a `tf-*` skill name

In these cases return immediately without reading context or applying the table.

---

## 5. Graceful degradation

When `state.mjs` is absent (TeamFlow not yet bootstrapped):
- Skip rule 5 (no active topics to resume).
- Skip the pack availability check (no metadata available).
- Route purely on message content using rules 2-13.
- If rule 4 or any `tf-*` skill is needed, output:
> TeamFlow is not installed. Run `npx teamflow-bootstrap install` to get started.

When `packs-meta.mjs` is absent but `state.mjs` exists (partial install):
- Apply all rules, but skip the pack availability check (§4 of SKILL.md).
- Invoke the skill and let it fail with a clear error if missing.
