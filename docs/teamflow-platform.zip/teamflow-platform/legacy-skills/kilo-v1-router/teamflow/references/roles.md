# TeamFlow — Roles

This file is loaded by the `teamflow` router skill when `userRole` needs to be resolved or when a skill needs to know which mode to preset.

---

## 1. Role definitions

| Role | Meaning | Default mode |
|---|---|---|
| `solo` | One developer working alone; no Jira, no team handoff required | `solo` |
| `team` | Developer working in a team context; Jira tickets, Stories, and handoffs expected | `team` |

---

## 2. Role resolution order (highest priority first)

1. **User message** — explicit override always wins.
   Signals: "for the team", "push to Jira", "create a ticket" → `team`.
   Signals: "just for me", "local only", "no Jira" → `solo`.
2. **`teamflow/config.yml`** field `defaultMode: solo | team`.
   Set by the team lead; applies to everyone working in this repository.
3. **`~/.teamflow/profile.json`** field `defaultRole: solo | team`.
   Set per workstation by the user or the bootstrap installer.
4. **Fallback**: `solo` — the safer default (never pushes to Jira without explicit confirmation).

---

## 3. Effect on routing

| Role | Effect |
|---|---|
| `solo` | `tf-specify` writes local files only; `tf-planify` produces `tasks.md`; no Jira push without explicit user request |
| `team` | `tf-specify` presets mode to `team`; `tf-planify` offers to create Jira Stories; `tf-archive` syncs Jira and opens a Bitbucket PR |

The router passes `userRole` in the context object to every downstream skill. Skills use it to preset their mode but always confirm with the user before writing to external systems (Jira, Bitbucket, Confluence).

---

## 4. Role in `~/.teamflow/profile.json`

Expected schema:

```json
{
  "defaultRole": "solo | team",
  "preferredSpecTypes": ["feature", "bug"],
  "jiraProject": "PROJ",
  "bitbucketProject": "MY-PROJECT",
  "bitbucketRepo": "my-service"
}
```

All fields except `defaultRole` are optional. Skills read the relevant fields directly; the router reads only `defaultRole`.

---

## 5. Role in `teamflow/config.yml`

Relevant excerpt:

```yaml
defaultMode: solo   # or: team
agent: kilo         # coding agent adapter

naming:
  branch: "feature/{topic}"
  bugBranch: "bugfix/{topic}"

review:
  skill: ""         # name of a custom review skill; empty = use default checklist
```

The router reads `defaultMode` and `agent` only. Other fields are consumed by the downstream skills that need them.
