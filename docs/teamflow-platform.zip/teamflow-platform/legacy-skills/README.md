# legacy-skills

Reference material only — nothing here is installed.

- `kilo-v1-router/`: the first Kilo router (agent + `teamflow` skill + references), replaced by `packages/teamflow-bootstrap`.
- Drop the old Kilo `tf-*` skills here to compare them with the new ones.
