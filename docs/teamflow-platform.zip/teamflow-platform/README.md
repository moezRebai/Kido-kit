# TeamFlow Platform

Routed, chainable delivery skills for Kilo Code (specify → plan → implement → review → finish), packaged as `teamflow-bootstrap`, plus a marketplace (later milestone).

- Specification: [`docs/spec/feature-spec.md`](docs/spec/feature-spec.md)
- Package: [`packages/teamflow-bootstrap`](packages/teamflow-bootstrap/README.md)
- Previous Kilo router, for reference: `legacy-skills/kilo-v1-router/`

## Quick start

```bash
cd packages/teamflow-bootstrap && npm install && npm test
cd /path/to/your/project && node /path/to/teamflow-platform/packages/teamflow-bootstrap/bin/teamflow.mjs install
```

## Credits

Most workflow skills are adapted from [obra/superpowers](https://github.com/obra/superpowers) (MIT). See `packages/teamflow-bootstrap/NOTICE.md`.
