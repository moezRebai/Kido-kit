# teamflow-bootstrap

Routed, chainable delivery skills for **Kilo Code**:
specify → plan → implement → review → finish, plus debug, TDD, documentation and more.
Every message goes through one router skill (`teamflow`); each skill can also be called directly and proposes the next one.

## Install in a project

```bash
npx teamflow-bootstrap install            # project: .kilo/skills, .kilo/agent, AGENTS.md
npx teamflow-bootstrap install --global   # user level: ~/.config/kilo/skills, ~/.config/kilo/agent
npx teamflow-bootstrap doctor             # check config, routes, installation
```

What it writes:

| File | Purpose |
|---|---|
| `.kilo/skills/<skill>/` | The `teamflow` router and the `tf-*` skills |
| `.kilo/agent/teamflow-router.md` | Router agent (`mode: primary`): loads `teamflow` on every message |
| `AGENTS.md` | A TeamFlow block (between markers) repeating the routing rule; Kilo loads it automatically |
| `.teamflow/config.yml` | Created once, then yours |
| `.teamflow/installed.json` | What was written, so re-runs never overwrite your edits |

Re-running is safe: files you edited are kept unless you pass `--force`.

## Skills

| Skill | Role | Origin |
|---|---|---|
| `teamflow` | Router: picks the skill for each message | TeamFlow |
| `tf-specify` | Dialogue → validated design → spec file | superpowers `brainstorming` |
| `tf-planify` | Spec → task-by-task implementation plan | superpowers `writing-plans` |
| `tf-implement` | Execute the plan inline, final review | superpowers `executing-plans` |
| `tf-implement-subagents` | Execute with a subagent + reviewer per task | superpowers `subagent-driven-development` |
| `tf-tdd` | Red → green → refactor | superpowers `test-driven-development` |
| `tf-review` | Request a code review | superpowers `requesting-code-review` |
| `tf-review-feedback` | Handle review comments with rigor | superpowers `receiving-code-review` |
| `tf-verify` | No "done" without evidence | superpowers `verification-before-completion` |
| `tf-finish` | Merge, PR or keep the branch | superpowers `finishing-a-development-branch` |
| `tf-worktree` | Isolated workspace | superpowers `using-git-worktrees` |
| `tf-debug` | Root cause before any fix | superpowers `systematic-debugging` |
| `tf-parallel-agents` | Independent problems in parallel | superpowers `dispatching-parallel-agents` |
| `tf-writing-skills` | Write and test new skills | superpowers `writing-skills` |
| `tf-document` | Docs grounded in the code | TeamFlow |

## Configuration (`.teamflow/config.yml`)

| Key | Values | Effect |
|---|---|---|
| `implement.mode` | `inline` \| `subagents` | Which implementation skill the router picks |
| `implement.tdd` | `required` \| `recommended` \| `off` | TDD in plans and implementation |
| `review.perTask` | `true` \| `false` | Per-task reviewer (subagents mode) |
| `review.final` | `true` \| `false` | Whole-branch review before finishing |
| `review.skill` | skill name | Replace `tf-review` with your own review skill |
| `review.checklist` | path | Team checklist given to the reviewer |
| `git.commitArtifacts` | `ask` \| `auto` \| `never` | Commits of specs and plans (never on the default branch without approval) |
| `paths.specs/plans/docs` | folders | Where artifacts are written |
| `adapters.kilo.agentDir` | folder | Override the agent folder if your Kilo version uses another one |

## Adding your own skills

```bash
npx teamflow-bootstrap new-skill release-notes   # .teamflow/skills/release-notes/SKILL.md + .teamflow/routes/release-notes.yml
# edit both files
npx teamflow-bootstrap sync                      # installs it in Kilo and adds its route to the router
```

A project skill with the same name as a package skill replaces it. A project route with the same `id` as a base route replaces it. `sync` refuses to install if a route points to a skill that does not exist.

## Known limits

- Routing is enforced by instructions (primary agent + `AGENTS.md`): strong, not absolute.
- Kilo paths (`.kilo/skills`, `.kilo/agent`) follow Kilo's docs; override `adapters.kilo.agentDir` if your version differs. Check with `kilo debug skill`.
- The skills were written for Claude Code; `skills/teamflow/references/platforms/kilo-tools.md` maps their vocabulary to Kilo.
- `tf-implement*` call bash scripts: on Windows, use Git Bash or WSL.
- `private: true` until the license is decided. See `NOTICE.md` before publishing.
